Apuntes:


Objetos iran subiendo barreras encima de la bola (simulando que la bola baja)
Cada x tiempo la bola aumentara de tama�o, esto hara que su vel disminuya
Cuando aumente de tama�o las barreras subiran mas rapido

Al colisionar con las barreras la bola se detiene y las barreras suben con la vel principal (lenta) ya que la bola vuelve a su estado original

Copos se mueven hacia los lados lijeramente

Cretidos en la parte final.

Animaciones Trineo.